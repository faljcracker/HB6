 <?php require 'src/pages/header.html'; ?>

  <?php require 'src/pages/home.php'; ?>

  <?php require 'src/pages/footer.html'; ?>


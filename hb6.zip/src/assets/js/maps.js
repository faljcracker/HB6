
 lat = 40.730610;
 lng = -73.935242;

 apiKey: 'AIzaSyAKmzlmATSxTIOUHagK35K5YAGwGLfI_a4'
